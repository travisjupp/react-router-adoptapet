import React from 'react';
import Navigation from '../navigation';
// import Outlet

const Root = () => {
    return (
        <>
            <Navigation/>
            {/* Add an Outlet*/}
        </>
    );
};

export default Root;